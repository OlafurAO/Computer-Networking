=================================================================
How to compile:
=================================================================
    -Simply type "make" into the command line and all of 
     the necessary programs will compile via the Makefile

=================================================================
How to run:
=================================================================
    -After compiling the programs you can run each of them
     by typing "./server <PORT>" and "./client <SERVER_IP> <SERVER_PORT>"

     Example: ./server 4098 
              ./client 127.0.0.1 4098

    